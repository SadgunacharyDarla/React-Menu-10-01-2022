import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import {Link}  from 'react-router-dom';

function Navbar() {
  return (
    <div>
      <header>
        <div className="container_nav">
          <input type="checkbox" name id="check" />
          <div className="logo-container">
            <h3 className="logo">SadgunaChary<span>Darla</span></h3>
          </div>
          <div className="nav-btn">
            <div className="nav-links">
              <ul>
                <li className="nav-link"><Link  to="/">Home</Link></li>

                <li className="nav-link"><Link  to="/Aboutus">About</Link></li>
                <li className="nav-link">
                  <a href="#">Practice Works<i className="fas fa-caret-down" /></a>
                  <div className="dropdown">
                    <ul>
                      <li className="dropdown-link"><Link  to="/Calci">Calci</Link> </li>
                      <li className="dropdown-link"><Link  to="/Covid">Covid</Link> </li>
                      <li className="dropdown-link"><Link  to="/Coviddatafetch">Coviddatafetch</Link></li>
                      <li className="dropdown-link"><Link  to="/CovidautoData">CovidAutoData</Link></li>

                      <li className="dropdown-link"><Link  to="/Todo">Todosearch</Link></li>


                      {/* <li className="dropdown-link"><Link  to="/Login">Log in</Link></li>
                      <li className="dropdown-link"><Link  to="/Signup">Sign up</Link></li> */}

                      <div className="arrow" />
                    </ul>
                  </div>
                </li>
                <li className="nav-link"><Link  to="/Login">Log in</Link></li>
                <li className="nav-link"><Link  to="/Signup">Sign up</Link></li>
              </ul>
            </div>
            {/* <div className="log-sign">
              <Link to="#" className="btn transparent">Log in</Link>
              <Link to="#" className="btn solid">Sign up</Link>
            </div> */}
          </div>
          <div className="hamburger-menu-container">
            <div className="hamburger-menu">
              <div />
            </div>
          </div>
        </div>
      </header>
    </div>
  )
}

export default Navbar;