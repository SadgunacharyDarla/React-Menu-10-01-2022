import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import Navbar from './components/Navbar';
import './assets/menu.css';
import './assets/style.css';
import Home from '../src/pages/Home';
import Aboutus from '../src/pages/Aboutus';
import Calci from '../src/pages/Calci';
import Covid from '../src/pages/Covid';
import Coviddatafetch from '../src/pages/Coviddatafetch';
import Notfound from '../src/pages/Notfound';
import Login from '../src/pages/login';
import Signup from '../src/pages/signup';
import CovidautoData from '../src/pages/Covidautodatafetch';
import Todo from './pages/todosearchdata';
import { BrowserRouter, Route, Switch } from "react-router-dom";



function App() {
  return (
    <div className="App">
        <BrowserRouter>
    <Navbar />     
    <div>
    <Switch>
      {/* <Route Path="/" exact="true" component={Home} />
      <Route Path="/Home"  component={Home} />
      <Route Path="/Aboutus"  component={Aboutus} />
      <Route Path="/Calci"  component={Calci} />
      <Route Path="/Covid" component={Covid} />
      <Route Path="/Coviddatafetch"  component={Coviddatafetch} />
      <Route Path="*"  component={Notfound} /> */}

<Route path="/" exact="true" strict>
<Home />
</Route>
<Route path="/Aboutus" strict>
<Aboutus />
</Route>
<Route path="/Calci" strict>
<Calci />
</Route>
<Route path="/CovidautoData" strict>
<CovidautoData />
</Route>
<Route path="/Covid" strict>
<Covid />
</Route>
<Route path="/Coviddatafetch" strict>
<Coviddatafetch />
</Route>
<Route path="/Login" strict>
<Login />
</Route>
<Route path="/Signup" strict>
<Signup />
</Route>

<Route path="/Todo" strict>
<Todo />
</Route>

<Route path="*" strict>
<Notfound />
</Route>

    </Switch>
    </div>
    </BrowserRouter>
    </div>
  );
}

export default App;
