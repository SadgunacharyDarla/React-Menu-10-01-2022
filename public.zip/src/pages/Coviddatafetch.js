import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import {Button} from 'react-bootstrap';
import fetch from 'node-fetch';
import {useState} from 'react';
// import Covidnewdata from '../pages/Covid' 
function Coviddatafetch(){
    const [data, updateData] = useState([]);
    const GetApi = async function () {
        const url ='https://raw.githubusercontent.com/nitishk72/flutter_json_list/master/json_example.json';
        const fgh = await fetch (url);
        const json = await fgh.json();
        updateData(json); 
    }; 
        return(
        <div className="container">
            <div className="row">
            <div className="col-md-12">
                <h5>Random Data</h5>
            </div>
            <Button onClick={GetApi} style={{width: '100%', marginBottom:'30px',}}>Get The Data</Button>
<br />
{
    data.map(asd => {
        return(
            <div className="col-md-4">
                <div className="head_area">

                        <p className="head_sec">Id:- <span>{asd.id} </span> </p>
                        <div className="head_padd"> 
                
                        <p>Name:- <span>{asd.name} </span> </p>
                        <p>Email:- <span>{asd.email} </span> </p>
                        <p>Address:- <span>{asd.address} </span> </p>
                   
                      </div>
                </div>
            </div>
        );
    })
}
</div>
</div>
    );
};
export default Coviddatafetch;