import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';

function Login(){
    return(
<div>
    <h1>Hello Login</h1>
</div>
    );

};
export default Login;