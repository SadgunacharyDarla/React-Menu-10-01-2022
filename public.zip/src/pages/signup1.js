// import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import {Form, Button,} from 'react-bootstrap'
import React, {useState} from 'react'

function Signup(){

    const [data, updateData] = useState({
        username:'',
        uemail:'',
        phonenumber:'',
        password:'',
        confirm_Password:'',

    });
    const {username,uemail,phonenumber,password,confirm_Password}=data;
   const changeHandler = (e) => {
    updateData({
...data,[e.target.name]:e.target.value
    })
   };
   const subMitform = (e) => {
e.preventDefault();
console.log(data)
   };
    return(
<div>
    <div className="container"> 
    <div className="row">
            <div className="col-md-6"> 
<Form onSubmit={subMitform}>
  <Form.Group controlId="">
    <Form.Label>Name</Form.Label>
    <Form.Control type="text" placeholder="Enter Your Name" name="username" value = {username} onChange={changeHandler} />

  </Form.Group>

  <Form.Group controlId="formBasicPassword">
    <Form.Label>Email Id</Form.Label>
    <Form.Control type="email" placeholder="Enter Email Id" name="uemail"  value = {uemail} onChange={changeHandler} />
  </Form.Group>

  <Form.Group controlId="formBasicPassword">
    <Form.Label>Mobile Number</Form.Label>
    <Form.Control type="Password" placeholder="Enter Your Mobile Number"  name="phonenumber" value = {phonenumber} onChange={changeHandler} />
  </Form.Group>

  <Form.Group controlId="formBasicPassword">
    <Form.Label>Password</Form.Label>
    <Form.Control type="Password" placeholder="Enter Password" name="password" value = {password} onChange={changeHandler}/>

        {
            password.length <= 6 ? <p>Password Must Contain 8 Characters </p> 
            :null 
        }

  </Form.Group>

  <Form.Group controlId="formBasicPassword">
    <Form.Label>Confirm Password</Form.Label>
    <Form.Control type="Password" placeholder="Enter Confirm Password" name="confirm_Password"value = {confirm_Password} onChange={changeHandler} />
  </Form.Group>

  <Button type="submt">
    Submit
  </Button>
</Form>
</div>

<div className="col-md-6">
  <h3> SignUp Details</h3>
  <table> 
      <thead>
      <th>Name </th>
      <th>Email</th>
      <th>Mobile Number</th>
      </thead>
      <tbody>
          <tr>
              <td>SADGUNACHARY</td>
              <td>sadgunasvapps@gmail.com</td>
              <td>7894561230</td>
          </tr>
      </tbody>
  </table>
</div>
</div>
</div>
</div>

    );

};
export default Signup;