import React, { createRef, useState } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import { Form, Button,Alert} from 'react-bootstrap'

function Signup(props) {


  const name = createRef();
  const email = createRef();
  const number = createRef();
  const password = createRef();
  const cnfpassword = createRef();
  const [errors, updateErrors] = useState([]);

  const submitForm = () => {
    const name_value = name.current.value;
    const email_value = email.current.value;
    const number_value = number.current.value;
    const password_value = password.current.value;
    const cnfpassword_value = cnfpassword.current.value;

    const Val = {
      name: name_value,
      email: email_value,
      number: number_value,
      password: password_value,
      cnfpassword: cnfpassword_value,

    };
    console.log(Val)

    const error_responses = [];
    if (Val.name.length < 3) {
      error_responses.push('Name must be greater than 3 letter');
    }
    if (Val.number.length < 16) {
      error_responses.push('Mobile Number must be 10 Numbers');
    }
    if (Val.number.length < 16) {
      error_responses.push('Mobile Number must be 10 Numbers');
    }
    if (Val.number.length < 16) {
      error_responses.push('Mobile Number must be 10 Numbers');
    }
        if (Val.number.length < 16) {
      error_responses.push('Mobile Number must be 10 Numbers');
    }
    updateErrors(error_responses);
  }

  return (
    <div>
      <div className="container">
        <div className="row">

          <div className="col-md-6">

            <h1>Hello World</h1>
<card>

{
            errors.map(e => <Alert variant="danger" key="e">{e}</Alert>)
          }
    
</card>
  
            <Form>
         <Form.Group hasValidation>
                <Form.Label>Name</Form.Label>
                <Form.Control type="text" ref={name} placeholder="Enter Your Name" name="username" />

              </Form.Group>

              <Form.Group controlId="formBasicPassword">
                <Form.Label>Email Id</Form.Label>
                <Form.Control type="email" ref={email} placeholder="Enter Email Id" name="uemail" />
              </Form.Group>

              <Form.Group controlId="formBasicPassword">
                <Form.Label>Mobile Number</Form.Label>
                <Form.Control type="number" ref={number} placeholder="Enter Your Mobile Number" name="phonenumber" />
              </Form.Group>

              <Form.Group controlId="formBasicPassword">
                <Form.Label>Password</Form.Label>
                <Form.Control type="Password" ref={password} placeholder="Enter Password" name="password" />

              </Form.Group>

              <Form.Group>
                <Form.Label>Confirm Password</Form.Label>
                <Form.Control type="Password" ref={cnfpassword} placeholder="Enter Confirm Password" name="confirm_Password" />
              </Form.Group>

              <Button onClick={submitForm}>
                Submit
              </Button>
            </Form>
          </div>
          
          <div className="col-md-6">
     
            <h3> SignUp Details</h3>
            <table>
              <thead>
                <th>Name </th>
                <th>Email</th>
                <th>Mobile Number</th>
              </thead>
              <tbody>
                <tr>
                  <td>SADGUNACHARY</td>  
                  <td>sadgunasvapps@gmail.com</td>
                  <td>7894561230</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

  );

};
export default Signup;