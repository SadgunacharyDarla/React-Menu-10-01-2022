import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';

function Covid(){
    return(
<div>
    <h1>Hello Covid</h1>
</div>
    );

};
export default Covid;