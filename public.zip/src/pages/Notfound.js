import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';

function Notfound(){
    return(
<div>
    <h1>Hello Notfound</h1>
</div>
    );

};
export default Notfound;