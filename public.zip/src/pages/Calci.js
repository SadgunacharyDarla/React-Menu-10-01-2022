import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';

function Calci(){
    return(
<div>
    <h1>Hello Calci</h1>
</div>
    );

};
export default Calci;