import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';

function Aboutus(){
    return(
<div>
    <h1>Hello AboutUS</h1>
</div>
    );

};
export default Aboutus;